# Frozen CIFAR validation-followup scientific source

This capsule reconstructs the exact scientific Python snapshots used by the
CIFAR-100 ViT pilot and expanded CIFAR-10 MLP followup. Shared files are stored
once in `blobs/`; `studies/pilot.json` and `studies/expanded.json` map their
original relative paths to SHA-256 hashes and define each recorded scientific
source fingerprint. Every retained Python file is byte-for-byte unchanged.
Deployment metadata, scheduler wrappers, data, credentials, and weights are
not included. The imported support package also retains unused definitions
needed to preserve each original source fingerprint; this archive does not
install a second framework into the public repository.

## Reconstruct and verify

Extract this archive into a separate directory, then run:

```sh
python reconstruct.py --study pilot --output /tmp/cifar-validation-pilot
python reconstruct.py --study expanded --output /tmp/cifar-validation-expanded
```

The helper needs only the Python standard library. It verifies every blob,
materializes the original relative paths, rereads every output file, and checks
the exact recorded scientific fingerprint. Existing files are accepted only
when their content matches. It does not run training or submit jobs.

The pilot fingerprint covers its runner and top-level support modules; the
expanded fingerprint covers its two scientific runners and all support Python
modules recursively. Additional support files in the pilot map preserve its
original package layout. `fingerprint_paths` makes the distinction explicit.

## Scientific use

Use Python 3.11 with the public repository's pinned `requirements.txt` in a
separate environment. Recorded runs used Python 3.11.15, PyTorch 2.1.0+cu121,
NumPy 1.24.3 and CUDA. From a reconstructed tree, inspect the original commands:

```sh
python experiments/tuning/run.py --help
python experiments/tuning/expanded.py --help
```

The first command is present in both snapshots; the second is in the expanded
snapshot. Scientific runs require locally staged official CIFAR data (or the
runners' explicit download option) and a new output directory. Consult the
public `results/cifar_validation_evidence.json` and methods appendix for exact
splits, grids, frozen profiles, selected recipes and confirmation seed IDs.
The archived runners may expose additional studies or stages; only the two
cohorts named in the manifests support the new validation-followup table.

Source hashes establish recovered code identity, not numerical identity across
different GPU kernels or library versions. The capsule contains no checkpoints
or per-epoch test histories. Profiles were predetermined from historical work;
validation selected optimizer settings and checkpoint epochs, while training
length stayed fixed. Fresh confirmation seeds do not create new CIFAR test sets.
