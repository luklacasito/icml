#!/usr/bin/env python3
"""Expand the CIFAR search, replicate its shortlist, and confirm on fresh seeds."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import math
import platform
import sys
import time
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "src")]
from experiments.tuning import run as pilot  # noqa: E402

TUNING_SEEDS = tuple(range(10, 15))
REPLICATION_SEEDS = tuple(range(20, 25))
CONFIRMATION_SEEDS = tuple(range(200, 210))
PROFILES = pilot.PROFILES
LR_FACTORS = (0.1, 1 / 3, 1.0, 3.0, 10.0)
BOOTSTRAP_SAMPLES = 10000


def source_hash():
    paths = [
        Path(__file__).resolve(),
        ROOT / "experiments/tuning/run.py",
        *sorted((ROOT / "src/dropout_mft").rglob("*.py")),
    ]
    return pilot.digest(
        {
            str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in paths
        }
    )


def make_plan(study, vit_size="full"):
    if study not in pilot.STUDIES or vit_size not in ("full", "pilot"):
        raise ValueError("Unknown study or ViT size")
    cfg = dict(pilot.STUDIES[study])
    if study == "vit" and vit_size == "full":
        cfg.update(train_size=45000, validation_size=5000, test_size=10000)
    weight_decays = sorted({cfg["base_decay"], 0.0, 1e-5, 1e-4, 1e-3, 1e-2})
    scientific = dict(
        schema=1,
        study=study,
        vit_size=vit_size if study == "vit" else "not_applicable",
        settings=cfg,
        split_seed=pilot.SPLIT_SEED,
        profiles=list(PROFILES),
        mean_dropout=0.1,
        learning_rates=[cfg["base_lr"] * factor for factor in LR_FACTORS],
        weight_decays=weight_decays,
        tuning_seeds=list(TUNING_SEEDS),
        replication_seeds=list(REPLICATION_SEEDS),
        confirmation_seeds=list(CONFIRMATION_SEEDS),
        shortlist_rule="two lowest mean minimum validation losses plus original",
        selection_rule="lowest replication mean minimum validation loss",
        primary_endpoint="test at each seed's minimum-validation-loss checkpoint",
        secondary_endpoint="fixed final-epoch test",
    )
    tune_count = (
        len(PROFILES) * len(LR_FACTORS) * len(weight_decays) * len(TUNING_SEEDS)
    )
    return dict(
        **scientific,
        protocol_hash=pilot.digest(scientific),
        source_hash=source_hash(),
        counts=dict(
            tune=tune_count, replicate_max=30, confirm_max=40, total_max=tune_count + 70
        ),
    )


@contextmanager
def locked(path, *, blocking=False):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as handle:
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        except BlockingIOError:
            raise RuntimeError(f"Another process owns {path}") from None
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def write_frozen(path, value):
    if path.exists() and json.loads(path.read_text()) != value:
        raise ValueError(f"Frozen {path.name} changed; use a new run directory")
    pilot.atomic_json(path, value)


def create_plan(run_dir, study, vit_size="full"):
    plan = make_plan(study, vit_size)
    with locked(run_dir / ".state.lock", blocking=True):
        write_frozen(run_dir / "plan.json", plan)
    return plan


def load_plan(run_dir):
    plan = json.loads((run_dir / "plan.json").read_text())
    expected = make_plan(
        plan["study"], plan["vit_size"] if plan["study"] == "vit" else "full"
    )
    if plan != expected:
        raise ValueError("Plan settings or source changed; use a new run directory")
    return plan


def bind_data(run_dir, plan, bundle):
    cfg = plan["settings"]
    if bundle.dataset != cfg["dataset"] or any(
        len(getattr(bundle, split)) != cfg[key]
        for split, key in (
            ("train", "train_size"),
            ("validation", "validation_size"),
            ("test", "test_size"),
        )
    ):
        raise ValueError("Loaded data do not match the planned dataset sizes")
    manifest = dict(
        **plan,
        split_hash=bundle.split_hash,
        split_protocol=bundle.split_protocol,
        test_subset_hash=bundle.test_subset_hash,
        test_subset_protocol=bundle.test_subset_protocol,
        test_subset_seed=bundle.test_subset_seed,
    )
    with locked(run_dir / ".state.lock", blocking=True):
        write_frozen(run_dir / "manifest.json", manifest)
    return manifest


def load_manifest(run_dir, plan):
    manifest = json.loads((run_dir / "manifest.json").read_text())
    if any(
        manifest.get(key) != value for key, value in plan.items()
    ) or not manifest.get("split_hash"):
        raise ValueError("Manifest does not match the frozen plan")
    return manifest


def original_parameters(plan):
    cfg = plan["settings"]
    return dict(learning_rate=cfg["base_lr"], weight_decay=cfg["base_decay"])


def trial_spec(plan, profile, parameters, seed, phase):
    if profile not in PROFILES or phase not in ("tune", "replicate", "confirm"):
        raise ValueError("Unknown profile or phase")
    if (
        parameters["learning_rate"] not in plan["learning_rates"]
        or parameters["weight_decay"] not in plan["weight_decays"]
    ):
        raise ValueError("Trial parameters are outside the frozen grid")
    expected_seeds = dict(
        tune=TUNING_SEEDS, replicate=REPLICATION_SEEDS, confirm=CONFIRMATION_SEEDS
    )
    if seed not in expected_seeds[phase]:
        raise ValueError("Trial seed is outside the planned phase")
    return dict(
        study=plan["study"],
        settings=plan["settings"],
        profile=profile,
        **parameters,
        seed=seed,
        phase=phase,
        evaluate_test=phase == "confirm",
        protocol_hash=plan["protocol_hash"],
    )


def tuning_specs(plan):
    return [
        trial_spec(plan, profile, dict(learning_rate=lr, weight_decay=wd), seed, "tune")
        for profile in PROFILES
        for lr in plan["learning_rates"]
        for wd in plan["weight_decays"]
        for seed in TUNING_SEEDS
    ]


def replication_specs(plan, shortlist):
    return [
        trial_spec(plan, profile, parameters, seed, "replicate")
        for profile in PROFILES
        for parameters in shortlist["candidates"][profile]
        for seed in REPLICATION_SEEDS
    ]


def confirmation_recipes(plan, selection):
    return {
        f"{kind}_{profile}": [
            trial_spec(plan, profile, parameters, seed, "confirm")
            for seed in CONFIRMATION_SEEDS
        ]
        for profile in PROFILES
        for kind, parameters in (
            ("fixed", original_parameters(plan)),
            ("tuned", selection["selected"][profile]),
        )
    }


def unique_specs(specs):
    return list({pilot.digest(spec): spec for spec in specs}.values())


def training_config(spec, device):
    cfg = spec["settings"]
    return pilot.TrainingConfig(
        epochs=cfg["epochs"],
        batch_size=cfg["batch_size"],
        learning_rate=spec["learning_rate"],
        weight_decay=spec["weight_decay"],
        lr_floor_ratio=cfg["lr_floor_ratio"],
        gradient_clip_norm=cfg["gradient_clip_norm"],
        seed=pilot.stream_seed(spec["seed"], "minibatches"),
        stochastic_seed=pilot.stream_seed(spec["seed"], "dropout"),
        evaluate_test=spec["evaluate_test"],
        restore_best_validation=True,
        device=device,
    )


def nonfinite_paths(value, prefix=""):
    if isinstance(value, dict):
        return [
            path
            for key, item in value.items()
            for path in nonfinite_paths(item, f"{prefix}/{key}")
        ]
    if isinstance(value, list):
        return [
            path
            for index, item in enumerate(value)
            for path in nonfinite_paths(item, f"{prefix}/{index}")
        ]
    if isinstance(value, float) and not math.isfinite(value):
        return [prefix]
    return []


def replace_nonfinite(value):
    if isinstance(value, dict):
        return {key: replace_nonfinite(item) for key, item in value.items()}
    if isinstance(value, list):
        return [replace_nonfinite(item) for item in value]
    return None if isinstance(value, float) and not math.isfinite(value) else value


def run_trial(spec, bundle, device, manifest):
    """Keep the pilot model/trainer; preserve explicit nonfinite outputs for audit."""
    cfg = spec["settings"]
    pilot.seed_everything(pilot.stream_seed(spec["seed"], "initialization"))
    layers = pilot.dropout_layers(spec)
    model = (
        pilot.build_mlp(
            pilot.MLPConfig(
                width=cfg["width"], depth=cfg["depth"], sigma_w_sq=1.98, sigma_b_sq=0.02
            ),
            layers,
        )
        if spec["study"] == "mlp"
        else pilot.TinyViT(
            layers,
            dimension=cfg["width"],
            heads=16,
            mlp_ratio=4.0,
            output_dim=100,
            patch_size=4,
        )
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=spec["learning_rate"], weight_decay=spec["weight_decay"]
    )
    started = time.monotonic()
    # Exceptions (OOM, missing data, CUDA errors, etc.) propagate and leave no
    # completed record. Only returned nonfinite metrics invalidate a candidate.
    training = pilot.as_json(
        pilot.train_model(model, optimizer, bundle, training_config(spec, device))
    )
    bad = nonfinite_paths(training)
    record = dict(
        status="invalid" if bad else "complete",
        spec=spec,
        spec_hash=pilot.digest(spec),
        source_hash=manifest["source_hash"],
        protocol_hash=manifest["protocol_hash"],
        split_hash=bundle.split_hash,
        duration_seconds=time.monotonic() - started,
        runtime=dict(
            python=platform.python_version(),
            torch=torch.__version__,
            numpy=np.__version__,
            device=device,
        ),
        training=replace_nonfinite(training),
    )
    if bad:
        record.update(invalid_reason="nonfinite_training_output", nonfinite_paths=bad)
    validate_record(record, spec, manifest)
    return record


def validate_record(record, spec, manifest):
    identity = dict(
        spec_hash=pilot.digest(spec),
        source_hash=manifest["source_hash"],
        protocol_hash=manifest["protocol_hash"],
        split_hash=manifest["split_hash"],
    )
    if record.get("spec") != spec or any(
        record.get(key) != value for key, value in identity.items()
    ):
        raise ValueError("Saved trial identity differs from the frozen study")
    if record.get("status") not in ("complete", "invalid"):
        raise ValueError("Trial is not a completed or explicitly invalid fit")
    training, cfg = record["training"], spec["settings"]
    device = training["training_config"]["device"]
    if training["training_config"] != asdict(training_config(spec, device)):
        raise ValueError("Saved training configuration differs from the trial")
    if (
        training["dataset"] != cfg["dataset"]
        or training["split_hash"] != manifest["split_hash"]
    ):
        raise ValueError("Training output uses a different dataset or split")
    required = {
        "train_loss",
        "train_accuracy",
        "validation_loss",
        "validation_accuracy",
    }
    if not required.issubset(training["history"]) or any(
        len(curve) != cfg["epochs"] for curve in training["history"].values()
    ):
        raise ValueError("Incomplete training or validation curves")
    test_keys = (
        "final_test_loss",
        "final_test_accuracy",
        "final_epoch_test_loss",
        "final_epoch_test_accuracy",
    )
    if not spec["evaluate_test"] and any(
        training[key] is not None for key in test_keys
    ):
        raise ValueError("Tuning and replication must never evaluate test data")
    if record["status"] == "invalid":
        paths = record.get("nonfinite_paths", [])
        if record.get("invalid_reason") != "nonfinite_training_output" or not paths:
            raise ValueError("Invalid fits require explicit nonfinite evidence")
        for path in paths:
            if not path.startswith(("/history/", "/final_test_", "/final_epoch_test_")):
                raise ValueError(
                    "Only nonfinite measured curves or endpoints invalidate candidates"
                )
            value = training
            for key in path.strip("/").split("/"):
                value = value[int(key)] if isinstance(value, list) else value[key]
            if value is not None:
                raise ValueError(
                    "Nonfinite evidence must match the stored null entries"
                )
        return
    pilot.validate_record(record, spec, manifest)
    curve = training["history"]["validation_loss"]
    if (
        training["test_epoch"] != int(np.argmin(curve))
        or training["test_protocol"] != "best_validation_epoch_single_evaluation_v1"
    ):
        raise ValueError(
            "Test checkpoint must equal the first minimum validation epoch"
        )
    if training["final_epoch_test_epoch"] != cfg["epochs"] - 1:
        raise ValueError("Final test endpoint must use the last epoch")
    for key in ("train_loss", "validation_loss"):
        if any(value < 0 for value in training["history"][key]):
            raise ValueError("Cross-entropy must be nonnegative")
    for key in ("train_accuracy", "validation_accuracy"):
        if any(not 0 <= value <= 1 for value in training["history"][key]):
            raise ValueError("Accuracy must use fraction units")
    if spec["evaluate_test"]:
        if any(training[key] < 0 for key in test_keys):
            raise ValueError("Test metrics must be nonnegative")
        if any(training[key] > 1 for key in test_keys if key.endswith("accuracy")):
            raise ValueError("Test accuracy must use fraction units")


def read_trial(run_dir, spec, manifest):
    path = pilot.trial_path(run_dir, spec)
    if not path.exists():
        return None
    record = json.loads(path.read_text())
    validate_record(record, spec, manifest)
    return record


def records_for(run_dir, specs, manifest):
    return [read_trial(run_dir, spec, manifest) for spec in specs]


def rank_candidates(records, expected_specs):
    if any(record is None for record in records):
        raise ValueError("Every planned seed must finish before selection")
    expected = {pilot.digest(spec) for spec in expected_specs}
    if (
        len(records) != len(expected)
        or {pilot.digest(record["spec"]) for record in records} != expected
    ):
        raise ValueError("Selection requires exactly the planned distinct trials")
    grouped = defaultdict(list)
    for record in records:
        spec = record["spec"]
        if spec["evaluate_test"] or spec["phase"] == "confirm":
            raise ValueError("Selection may use only validation-only trials")
        grouped[(spec["profile"], spec["learning_rate"], spec["weight_decay"])].append(
            record
        )
    rankings = {profile: [] for profile in PROFILES}
    invalid = []
    for (profile, lr, wd), runs in grouped.items():
        runs.sort(key=lambda record: record["spec"]["seed"])
        parameters = dict(learning_rate=lr, weight_decay=wd)
        if any(record["status"] != "complete" for record in runs):
            invalid.append(
                dict(
                    profile=profile,
                    **parameters,
                    invalid_seeds=[
                        r["spec"]["seed"] for r in runs if r["status"] != "complete"
                    ],
                )
            )
            continue
        values = [
            min(record["training"]["history"]["validation_loss"]) for record in runs
        ]
        if not np.isfinite(values).all():
            raise ValueError("Nonfinite values cannot enter ranking")
        rankings[profile].append(
            dict(
                **parameters,
                mean_minimum_validation_loss=float(np.mean(values)),
                seeds=[r["spec"]["seed"] for r in runs],
                per_seed_minimum_validation_loss=values,
            )
        )
    for rows in rankings.values():
        rows.sort(
            key=lambda row: (
                row["mean_minimum_validation_loss"],
                row["learning_rate"],
                row["weight_decay"],
            )
        )
    return rankings, invalid


def parameters(row):
    return {key: row[key] for key in ("learning_rate", "weight_decay")}


def make_shortlist(plan, records):
    rankings, invalid = rank_candidates(records, tuning_specs(plan))
    original = original_parameters(plan)
    candidates = {}
    for profile in PROFILES:
        rows = rankings[profile]
        if original not in [parameters(row) for row in rows]:
            raise ValueError(
                f"Original {profile} configuration has an invalid tuning seed"
            )
        chosen = [parameters(row) for row in rows[:2]]
        if original not in chosen:
            chosen.append(original)
        candidates[profile] = chosen
    return dict(
        protocol_hash=plan["protocol_hash"],
        source_hash=plan["source_hash"],
        candidates=candidates,
        rankings=rankings,
        invalid_candidates=invalid,
        tuning_records_hash=pilot.digest(records),
    )


def select_replication(plan, shortlist, records):
    rankings, invalid = rank_candidates(records, replication_specs(plan, shortlist))
    selected = {}
    for profile in PROFILES:
        if original_parameters(plan) not in [
            parameters(row) for row in rankings[profile]
        ]:
            raise ValueError(
                f"Original {profile} configuration has an invalid replication seed"
            )
        selected[profile] = parameters(rankings[profile][0])
    boundaries = {
        profile: dict(
            learning_rate_at_lower_edge=chosen["learning_rate"]
            == min(plan["learning_rates"]),
            learning_rate_at_upper_edge=chosen["learning_rate"]
            == max(plan["learning_rates"]),
            weight_decay_at_upper_edge=chosen["weight_decay"]
            == max(plan["weight_decays"]),
        )
        for profile, chosen in selected.items()
    }
    return dict(
        protocol_hash=plan["protocol_hash"],
        source_hash=plan["source_hash"],
        selected=selected,
        rankings=rankings,
        invalid_candidates=invalid,
        shortlist_hash=pilot.digest(shortlist),
        replication_records_hash=pilot.digest(records),
        selection_rule=plan["selection_rule"],
        grid_boundaries=boundaries,
    )


def checked_shortlist(run_dir, plan, manifest):
    specs = tuning_specs(plan)
    expected = make_shortlist(plan, records_for(run_dir, specs, manifest))
    actual = json.loads((run_dir / "shortlist.json").read_text())
    if actual != expected:
        raise ValueError("Frozen shortlist differs from tuning records")
    return actual


def checked_selection(run_dir, plan, manifest):
    shortlist = checked_shortlist(run_dir, plan, manifest)
    specs = replication_specs(plan, shortlist)
    expected = select_replication(
        plan, shortlist, records_for(run_dir, specs, manifest)
    )
    actual = json.loads((run_dir / "selection.json").read_text())
    if actual != expected:
        raise ValueError("Frozen selection differs from replication records")
    return actual


def stage_specs(run_dir, stage):
    plan = load_plan(run_dir)
    if stage == "tune":
        return tuning_specs(plan)
    manifest = load_manifest(run_dir, plan)
    if stage == "replicate":
        return replication_specs(plan, checked_shortlist(run_dir, plan, manifest))
    if stage == "confirm":
        recipes = confirmation_recipes(plan, checked_selection(run_dir, plan, manifest))
        return unique_specs([spec for specs in recipes.values() for spec in specs])
    raise ValueError("Unknown stage")


def statistics(values):
    values = np.asarray(values, dtype=float)
    sd = float(np.std(values, ddof=1))
    return dict(
        mean=float(np.mean(values)),
        sd=sd,
        sem=sd / math.sqrt(len(values)),
        per_seed=values.tolist(),
    )


def paired_comparison(treatment, baseline, seed):
    a_loss, b_loss = np.asarray(treatment["loss"]), np.asarray(baseline["loss"])
    a_acc, b_acc = (
        np.asarray(treatment["accuracy_percent"]),
        np.asarray(baseline["accuracy_percent"]),
    )
    if (
        a_loss.shape != b_loss.shape
        or a_acc.shape != b_acc.shape
        or len(a_loss) != len(CONFIRMATION_SEEDS)
        or np.any(b_loss <= 0)
    ):
        raise ValueError(
            "Paired comparisons need all ten seeds and positive baseline loss"
        )
    indices = np.random.default_rng(seed).integers(
        0, len(a_loss), size=(BOOTSTRAP_SAMPLES, len(a_loss))
    )
    bootstrap_loss = (
        100
        * (b_loss[indices].mean(axis=1) - a_loss[indices].mean(axis=1))
        / b_loss[indices].mean(axis=1)
    )
    bootstrap_acc = (a_acc[indices] - b_acc[indices]).mean(axis=1)
    return dict(
        loss_reduction_percent=100
        * float((b_loss.mean() - a_loss.mean()) / b_loss.mean()),
        loss_reduction_ci95=np.quantile(bootstrap_loss, (0.025, 0.975)).tolist(),
        accuracy_gain_pp=float((a_acc - b_acc).mean()),
        accuracy_gain_pp_ci95=np.quantile(bootstrap_acc, (0.025, 0.975)).tolist(),
        paired_loss_difference=statistics(a_loss - b_loss),
        paired_accuracy_difference_pp=statistics(a_acc - b_acc),
        bootstrap_samples=BOOTSTRAP_SAMPLES,
        bootstrap_seed=seed,
    )


def summarize(run_dir, plan, manifest, shortlist, selection):
    recipes = confirmation_recipes(plan, selection)
    raw, summaries = {}, {}
    for name, specs in recipes.items():
        records = records_for(run_dir, specs, manifest)
        if any(record is None or record["status"] != "complete" for record in records):
            raise ValueError(
                "Confirmation summaries require all ten finite paired seeds"
            )
        raw[name], summaries[name] = {}, {}
        for endpoint, prefix in (
            ("best_validation", "final_test"),
            ("final_epoch", "final_epoch_test"),
        ):
            values = dict(
                loss=[r["training"][prefix + "_loss"] for r in records],
                accuracy_percent=[
                    100 * r["training"][prefix + "_accuracy"] for r in records
                ],
            )
            raw[name][endpoint] = values
            summaries[name][endpoint] = {
                key: statistics(items) for key, items in values.items()
            }
    comparisons = {}
    for treatment, baseline in (
        ("tuned_frontloaded", "tuned_uniform"),
        ("tuned_frontloaded", "fixed_frontloaded"),
        ("fixed_frontloaded", "fixed_uniform"),
        ("tuned_uniform", "fixed_uniform"),
    ):
        name = f"{treatment}_vs_{baseline}"
        comparisons[name] = {
            endpoint: paired_comparison(
                raw[treatment][endpoint],
                raw[baseline][endpoint],
                pilot.stream_seed(20260921, name + endpoint),
            )
            for endpoint in ("best_validation", "final_epoch")
        }
    diagnostics = {}
    for profile in PROFILES:
        chosen = selection["selected"][profile]
        tune = next(
            row for row in shortlist["rankings"][profile] if parameters(row) == chosen
        )
        replication = next(
            row for row in selection["rankings"][profile] if parameters(row) == chosen
        )
        diagnostics[profile] = dict(
            parameters=chosen,
            tuning_mean_minimum_validation_loss=tune["mean_minimum_validation_loss"],
            replication_mean_minimum_validation_loss=replication[
                "mean_minimum_validation_loss"
            ],
        )
    return dict(
        status="complete",
        study=plan["study"],
        vit_size=plan["vit_size"],
        settings=plan["settings"],
        seeds=list(CONFIRMATION_SEEDS),
        selected=selection["selected"],
        recipes=summaries,
        paired_comparisons=comparisons,
        selection_diagnostics=diagnostics,
        grid_boundaries=selection["grid_boundaries"],
        source_hash=plan["source_hash"],
        protocol_hash=plan["protocol_hash"],
        split_hash=manifest["split_hash"],
        note="Paired percentile bootstrap over ten training seeds on one fixed split; selection used validation-only tuning and replication seeds.",
    )


def advance(run_dir):
    plan = load_plan(run_dir)
    with locked(run_dir / ".state.lock", blocking=True):
        if not (run_dir / "manifest.json").exists():
            return dict(
                status="tuning",
                next_stage="tune",
                completed=0,
                required=plan["counts"]["tune"],
            )
        manifest = load_manifest(run_dir, plan)
        tune_specs = tuning_specs(plan)
        tuning = records_for(run_dir, tune_specs, manifest)
        if any(record is None for record in tuning):
            return dict(
                status="tuning",
                next_stage="tune",
                completed=sum(r is not None for r in tuning),
                required=len(tuning),
            )
        shortlist = make_shortlist(plan, tuning)
        write_frozen(run_dir / "shortlist.json", shortlist)
        replicate_specs = replication_specs(plan, shortlist)
        replicated = records_for(run_dir, replicate_specs, manifest)
        if any(record is None for record in replicated):
            return dict(
                status="replication",
                next_stage="replicate",
                completed=sum(r is not None for r in replicated),
                required=len(replicated),
            )
        selection = select_replication(plan, shortlist, replicated)
        write_frozen(run_dir / "selection.json", selection)
        recipes = confirmation_recipes(plan, selection)
        confirm_specs = unique_specs(
            [spec for specs in recipes.values() for spec in specs]
        )
        confirmed = records_for(run_dir, confirm_specs, manifest)
        if any(record is None for record in confirmed):
            return dict(
                status="confirmation",
                next_stage="confirm",
                completed=sum(r is not None for r in confirmed),
                required=len(confirmed),
            )
        if any(record["status"] != "complete" for record in confirmed):
            return dict(
                status="invalid_confirmation",
                next_stage=None,
                invalid_trials=[
                    r["spec_hash"] for r in confirmed if r["status"] != "complete"
                ],
            )
        summary = summarize(run_dir, plan, manifest, shortlist, selection)
        write_frozen(run_dir / "summary.json", summary)
        return dict(
            status="complete",
            next_stage=None,
            completed=len(confirmed),
            required=len(confirmed),
            summary_path=str(run_dir / "summary.json"),
        )


def smoke_specs(plan):
    return [
        trial_spec(plan, profile, original_parameters(plan), TUNING_SEEDS[0], "tune")
        for profile in PROFILES
    ]


def validate_smoke(run_dir):
    plan = load_plan(run_dir)
    manifest = load_manifest(run_dir, plan)
    records = records_for(run_dir, smoke_specs(plan), manifest)
    if any(record is None or record["status"] != "complete" for record in records):
        raise ValueError("Smoke requires two completed finite original-recipe fits")
    report = dict(
        status="complete",
        study=plan["study"],
        vit_size=plan["vit_size"],
        settings=plan["settings"],
        source_hash=plan["source_hash"],
        protocol_hash=plan["protocol_hash"],
        split_hash=manifest["split_hash"],
        runs=[
            dict(
                profile=r["spec"]["profile"],
                spec_hash=r["spec_hash"],
                duration_seconds=r["duration_seconds"],
                device=r["training"]["device"],
                epochs=r["spec"]["settings"]["epochs"],
                evaluate_test=r["spec"]["evaluate_test"],
            )
            for r in records
        ],
        total_seconds=sum(r["duration_seconds"] for r in records),
    )
    path = run_dir / "smoke.json"
    if path.exists() and json.loads(path.read_text()) != report:
        raise ValueError("Smoke summary differs from the trial records")
    return report


def execute_work(args):
    run_dir = args.run_dir
    plan = load_plan(run_dir)
    specs = (
        smoke_specs(plan)
        if args.command == "smoke"
        else stage_specs(run_dir, args.stage)[args.index :: args.count]
    )
    started = time.monotonic()
    cfg = plan["settings"]
    bundle = pilot.load_cifar_bundle(
        cfg["dataset"],
        root=args.data_root,
        train_size=cfg["train_size"],
        validation_size=cfg["validation_size"],
        test_size=cfg["test_size"],
        split_seed=plan["split_seed"],
        download=False,
    )
    manifest = bind_data(run_dir, plan, bundle)
    completed = 0
    for spec in specs:
        with locked(run_dir / "locks" / f"{pilot.digest(spec)}.lock"):
            if read_trial(run_dir, spec, manifest) is not None:
                completed += 1
                continue
            if time.monotonic() - started >= args.max_seconds:
                break
            print(
                f"{spec['phase']} {spec['profile']} seed={spec['seed']} lr={spec['learning_rate']:g} wd={spec['weight_decay']:g}",
                flush=True,
            )
            record = run_trial(spec, bundle, args.device, manifest)
            pilot.atomic_json(pilot.trial_path(run_dir, spec), record)
            completed += 1
            print(
                f"saved {record['status']} {record['spec_hash'][:12]} ({record['duration_seconds']:.1f}s)",
                flush=True,
            )
    if args.command == "smoke":
        report = validate_smoke(run_dir)
        with locked(run_dir / ".state.lock", blocking=True):
            write_frozen(run_dir / "smoke.json", report)
        return report
    return dict(
        status="complete" if completed == len(specs) else "partial",
        stage=args.stage,
        completed=completed,
        required=len(specs),
        index=args.index,
        count=args.count,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("plan", "work", "advance", "smoke"):
        child = commands.add_parser(command)
        child.add_argument("--run-dir", type=Path, required=True)
        if command == "plan":
            child.add_argument("--study", choices=("mlp", "vit"), required=True)
            child.add_argument("--vit-size", choices=("full", "pilot"), default="full")
        if command in ("work", "smoke"):
            child.add_argument("--data-root", type=Path, required=True)
            child.add_argument(
                "--device", choices=("auto", "cpu", "cuda"), default="cuda"
            )
            child.add_argument("--max-seconds", type=float, default=6600)
            child.add_argument("--threads", type=int, default=4)
        if command == "work":
            child.add_argument(
                "--stage", choices=("tune", "replicate", "confirm"), required=True
            )
            child.add_argument("--index", type=int, default=0)
            child.add_argument("--count", type=int, default=1)
    args = parser.parse_args()
    if args.command == "plan":
        result = create_plan(args.run_dir, args.study, args.vit_size)
    elif args.command == "advance":
        result = advance(args.run_dir)
    else:
        if (
            not math.isfinite(args.max_seconds)
            or args.max_seconds <= 0
            or args.threads < 1
        ):
            parser.error(
                "Time budget must be finite and positive; threads must be positive"
            )
        if args.command == "work" and not 0 <= args.index < args.count:
            parser.error("Require 0 <= index < count")
        torch.set_num_threads(args.threads)
        result = execute_work(args)
    print(json.dumps(pilot.as_json(result), indent=2), flush=True)
    if args.command == "work" and result["status"] != "complete":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
