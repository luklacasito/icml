#!/usr/bin/env python3
"""Small, separately tuned uniform/frontloaded comparisons on CIFAR."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import platform
import sys
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import TensorDataset

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from dropout_mft.models import MLPConfig, TinyViT, build_mlp  # noqa: E402
from dropout_mft.training import (  # noqa: E402
    TrainingConfig,
    load_cifar_bundle,
    seed_everything,
    synthetic_bundle,
    train_model,
)

STUDIES = {
    "mlp": dict(
        dataset="cifar10",
        depth=6,
        width=256,
        classes=10,
        train_size=4000,
        validation_size=1000,
        test_size=5000,
        batch_size=100,
        epochs=75,
        base_lr=1e-4,
        base_decay=1e-7,
        lr_floor_ratio=0.001,
        gradient_clip_norm=None,
    ),
    "vit": dict(
        dataset="cifar100",
        depth=12,
        width=128,
        classes=100,
        train_size=1600,
        validation_size=400,
        test_size=5000,
        batch_size=250,
        epochs=75,
        base_lr=5e-4,
        base_decay=0.0,
        lr_floor_ratio=0.01,
        gradient_clip_norm=1.0,
    ),
}
SPLIT_SEED = 20260920
TUNING_SEEDS = (0, 1)
CONFIRMATION_SEEDS = (100, 101, 102)
PROFILES = ("uniform", "frontloaded")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def source_hash():
    # Include __init__ and the shared modules it imports alongside the trainer.
    paths = [Path(__file__), *sorted((ROOT / "src/dropout_mft").glob("*.py"))]
    return digest(
        {
            str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in paths
        }
    )


def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temporary.write_text(
            json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
        )
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def as_json(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {key: as_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [as_json(item) for item in value]
    return value


def trial_spec(study, profile, learning_rate, weight_decay, seed, phase):
    return dict(
        study=study,
        settings=STUDIES[study],
        profile=profile,
        learning_rate=learning_rate,
        weight_decay=weight_decay,
        seed=seed,
        phase=phase,
        evaluate_test=phase == "confirm",
    )


def tuning_specs(study):
    cfg = STUDIES[study]
    return [
        trial_spec(study, profile, lr, wd, seed, "tune")
        for profile in PROFILES
        for lr in (cfg["base_lr"] / 3, cfg["base_lr"], cfg["base_lr"] * 3)
        for wd in (cfg["base_decay"], 1e-4, 1e-2)
        for seed in TUNING_SEEDS
    ]


def confirmation_specs(study, selection):
    cfg = STUDIES[study]
    recipes = {}
    for profile in PROFILES:
        for kind in ("fixed", "tuned"):
            params = (
                dict(learning_rate=cfg["base_lr"], weight_decay=cfg["base_decay"])
                if kind == "fixed"
                else selection["selected"][profile]
            )
            recipes[f"{kind}_{profile}"] = [
                trial_spec(
                    study,
                    profile,
                    params["learning_rate"],
                    params["weight_decay"],
                    seed,
                    "confirm",
                )
                for seed in CONFIRMATION_SEEDS
            ]
    return recipes


def dropout_layers(spec):
    depth = spec["settings"]["depth"]
    if spec["profile"] == "uniform":
        return [0.1] * depth
    if spec["study"] == "mlp":
        return [0.3, 0.3, 0.0, 0.0, 0.0, 0.0]
    return np.linspace(0.2, 0.0, depth).tolist()


def stream_seed(seed, stream):
    return int(digest(dict(seed=seed, stream=stream))[:8], 16)


def validate_record(record, spec, manifest):
    expected = {
        "spec_hash": digest(spec),
        "source_hash": manifest["source_hash"],
        "split_hash": manifest["split_hash"],
        "status": "complete",
    }
    if (
        any(record.get(k) != v for k, v in expected.items())
        or record.get("spec") != spec
    ):
        raise ValueError("Saved trial identity changed; use a new run directory.")
    training = record["training"]
    for key, curve in training["history"].items():
        values = np.asarray(curve, dtype=float)
        if len(values) != spec["settings"]["epochs"] or not np.isfinite(values).all():
            raise ValueError(f"Incomplete or nonfinite {key} in {record['spec_hash']}")
    for key in (
        "final_test_loss",
        "final_test_accuracy",
        "final_epoch_test_loss",
        "final_epoch_test_accuracy",
    ):
        value = training[key]
        if spec["evaluate_test"]:
            if value is None or not np.isfinite(value):
                raise ValueError(f"Invalid confirmation endpoint {key}")
        elif value is not None:
            raise ValueError("A tuning trial evaluated the test set.")


def trial_path(run_dir, spec):
    return run_dir / "trials" / f"{digest(spec)}.json"


def read_trial(run_dir, spec, manifest):
    path = trial_path(run_dir, spec)
    if not path.exists():
        return None
    record = json.loads(path.read_text())
    validate_record(record, spec, manifest)
    return record


def run_trial(spec, bundle, device, manifest):
    cfg = spec["settings"]
    seed_everything(stream_seed(spec["seed"], "initialization"))
    layers = dropout_layers(spec)
    if spec["study"] == "mlp":
        model = build_mlp(
            MLPConfig(
                width=cfg["width"], depth=cfg["depth"], sigma_w_sq=1.98, sigma_b_sq=0.02
            ),
            layers,
        )
    else:
        model = TinyViT(
            layers,
            dimension=cfg["width"],
            heads=16,
            mlp_ratio=4.0,
            output_dim=100,
            patch_size=4,
        )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=spec["learning_rate"], weight_decay=spec["weight_decay"]
    )
    config = TrainingConfig(
        epochs=cfg["epochs"],
        batch_size=cfg["batch_size"],
        learning_rate=spec["learning_rate"],
        weight_decay=spec["weight_decay"],
        lr_floor_ratio=cfg["lr_floor_ratio"],
        gradient_clip_norm=cfg["gradient_clip_norm"],
        seed=stream_seed(spec["seed"], "minibatches"),
        stochastic_seed=stream_seed(spec["seed"], "dropout"),
        evaluate_test=spec["evaluate_test"],
        restore_best_validation=True,
        device=device,
    )
    started = time.monotonic()
    training = train_model(model, optimizer, bundle, config)
    record = dict(
        status="complete",
        spec=spec,
        spec_hash=digest(spec),
        source_hash=manifest["source_hash"],
        split_hash=bundle.split_hash,
        duration_seconds=time.monotonic() - started,
        runtime=dict(
            python=platform.python_version(),
            torch=torch.__version__,
            numpy=np.__version__,
            device=device,
        ),
        training=as_json(training),
    )
    validate_record(record, spec, manifest)
    return record


def select_trials(records):
    if len(records) != 36 or len({digest(r["spec"]) for r in records}) != 36:
        raise ValueError("Selection requires 36 distinct tuning trials.")
    if any(r["spec"]["phase"] != "tune" or r["spec"]["evaluate_test"] for r in records):
        raise ValueError("Only validation-only tuning trials may enter selection.")
    selected, rankings = {}, {}
    for profile in PROFILES:
        grouped = {}
        for record in records:
            spec = record["spec"]
            if spec["profile"] == profile:
                key = (spec["learning_rate"], spec["weight_decay"])
                curve = np.asarray(
                    record["training"]["history"]["validation_loss"], dtype=float
                )
                if not curve.size or not np.isfinite(curve).all():
                    raise ValueError("Nonfinite validation objective")
                values = grouped.setdefault(key, {})
                if spec["seed"] in values:
                    raise ValueError("Duplicate tuning seed for a configuration")
                values[spec["seed"]] = float(curve.min())
        if len(grouped) != 9 or any(
            set(v) != set(TUNING_SEEDS) for v in grouped.values()
        ):
            raise ValueError("Selection requires all 36 tuning trials.")
        rows = [
            dict(
                learning_rate=lr,
                weight_decay=wd,
                mean_minimum_validation_loss=float(np.mean(list(values.values()))),
            )
            for (lr, wd), values in grouped.items()
        ]
        rankings[profile] = sorted(
            rows,
            key=lambda r: (
                r["mean_minimum_validation_loss"],
                r["learning_rate"],
                r["weight_decay"],
            ),
        )
        selected[profile] = {
            k: rankings[profile][0][k] for k in ("learning_rate", "weight_decay")
        }
    return dict(
        selected=selected,
        rankings=rankings,
        objective="mean minimum validation cross-entropy across seeds 0 and 1",
        tuning_records_hash=digest(records),
    )


def statistics(values):
    return dict(
        mean=float(np.mean(values)), sd=float(np.std(values, ddof=1)), per_seed=values
    )


def summarize(run_dir):
    manifest = json.loads((run_dir / "manifest.json").read_text())
    selection_path = run_dir / "selection.json"
    if not selection_path.exists():
        count = sum(
            read_trial(run_dir, s, manifest) is not None
            for s in tuning_specs(manifest["study"])
        )
        return dict(status="tuning", completed=count, required=36)
    selection = json.loads(selection_path.read_text())
    recipes = confirmation_specs(manifest["study"], selection)
    raw, summaries = {}, {}
    for name, specs in recipes.items():
        records = [read_trial(run_dir, spec, manifest) for spec in specs]
        if any(record is None for record in records):
            summaries[name] = dict(
                completed=sum(r is not None for r in records), required=3
            )
            continue
        raw[name], summaries[name] = {}, {}
        for endpoint, prefix in (
            ("best_validation", "final_test"),
            ("final_epoch", "final_epoch_test"),
        ):
            values = dict(
                loss=[r["training"][prefix + "_loss"] for r in records],
                accuracy_percent=[
                    100 * r["training"][prefix + "_accuracy"] for r in records
                ],
            )
            raw[name][endpoint] = values
            summaries[name][endpoint] = {
                key: statistics(value) for key, value in values.items()
            }
    comparisons = {}
    for treatment, baseline in (
        ("tuned_frontloaded", "tuned_uniform"),
        ("tuned_frontloaded", "fixed_frontloaded"),
        ("fixed_frontloaded", "fixed_uniform"),
        ("tuned_uniform", "fixed_uniform"),
    ):
        if treatment not in raw or baseline not in raw:
            continue
        comparisons[f"{treatment}_vs_{baseline}"] = {}
        for endpoint in ("best_validation", "final_epoch"):
            a, b = raw[treatment][endpoint], raw[baseline][endpoint]
            improvement = [
                100 * (y - x) / y for x, y in zip(a["loss"], b["loss"], strict=True)
            ]
            accuracy = [
                x - y
                for x, y in zip(
                    a["accuracy_percent"], b["accuracy_percent"], strict=True
                )
            ]
            comparisons[f"{treatment}_vs_{baseline}"][endpoint] = dict(
                loss_reduction_percent=statistics(improvement),
                accuracy_gain_pp=statistics(accuracy),
            )
    return dict(
        status="complete" if len(raw) == 4 else "confirmation",
        seeds=list(CONFIRMATION_SEEDS),
        selected=selection["selected"],
        recipes=summaries,
        paired_comparisons=comparisons,
        note="Three paired seeds; SD describes seed variation, not a confidence interval.",
    )


def load_data(args):
    cfg = STUDIES[args.study]
    if args.command == "smoke" and args.synthetic:
        bundle = synthetic_bundle(
            input_dim=3072,
            classes=cfg["classes"],
            train_size=8,
            validation_size=4,
            test_size=4,
            seed=SPLIT_SEED,
        )

        def images(data):
            x, y = data.tensors
            return TensorDataset(x.reshape(-1, 3, 32, 32), y)

        return replace(
            bundle,
            dataset=cfg["dataset"],
            train=images(bundle.train),
            validation=images(bundle.validation),
            test=images(bundle.test),
            split_hash=digest(
                dict(study=args.study, mode="synthetic", seed=SPLIT_SEED)
            ),
        )
    sizes = {key: cfg[key] for key in ("train_size", "validation_size", "test_size")}
    if args.command == "smoke" and not args.real:
        sizes = dict(
            train_size=cfg["classes"] * 2, validation_size=cfg["classes"], test_size=100
        )
    return load_cifar_bundle(
        cfg["dataset"],
        root=args.data_root,
        **sizes,
        split_seed=SPLIT_SEED,
        download=args.download,
    )


def execute(args):
    run_dir = args.run_dir
    run_dir.mkdir(parents=True, exist_ok=True)
    with (run_dir / ".lock").open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit(
                f"Another process owns {run_dir}; no trials started."
            ) from None
        started = time.monotonic()
        bundle = load_data(args)
        manifest = dict(
            schema=1,
            mode=args.command,
            study=args.study,
            settings=STUDIES[args.study],
            split_seed=SPLIT_SEED,
            split_hash=bundle.split_hash,
            source_hash=source_hash(),
            tuning_seeds=list(TUNING_SEEDS),
            confirmation_seeds=list(CONFIRMATION_SEEDS),
        )
        path = run_dir / "manifest.json"
        if path.exists() and json.loads(path.read_text()) != manifest:
            raise ValueError(
                "Run configuration, data split, or source changed; use a new run directory."
            )
        atomic_json(path, manifest)
        atomic_json(
            run_dir / "runtime.json",
            dict(
                python=platform.python_version(),
                torch=torch.__version__,
                numpy=np.__version__,
                device=args.device,
            ),
        )

        def ensure(spec):
            existing = read_trial(run_dir, spec, manifest)
            if existing is not None:
                return existing
            if time.monotonic() - started >= args.max_seconds:
                raise TimeoutError(
                    "Time budget reached before the next trial; rerun this command to resume."
                )
            print(
                f"{spec['phase']} {spec['profile']} seed={spec['seed']} "
                f"lr={spec['learning_rate']:g} wd={spec['weight_decay']:g}",
                flush=True,
            )
            record = run_trial(spec, bundle, args.device, manifest)
            atomic_json(trial_path(run_dir, spec), record)
            print(
                f"saved {digest(spec)[:12]} ({record['duration_seconds']:.1f}s)",
                flush=True,
            )
            return record

        if args.command == "smoke":
            cfg = STUDIES[args.study]
            phases = (
                (("uniform", "tune"),)
                if not args.synthetic
                else (("uniform", "tune"), ("frontloaded", "confirm"))
            )
            smoke_records = []
            for profile, phase in phases:
                spec = trial_spec(
                    args.study, profile, cfg["base_lr"], cfg["base_decay"], 0, phase
                )
                spec["settings"] = {
                    **cfg,
                    "epochs": 1,
                    "train_size": len(bundle.train),
                    "validation_size": len(bundle.validation),
                    "test_size": len(bundle.test),
                }
                smoke_records.append(ensure(spec))
            atomic_json(
                run_dir / f"smoke_{args.study}.json",
                dict(
                    status="complete",
                    study=args.study,
                    real=args.real,
                    epoch_seconds=smoke_records[0]["duration_seconds"],
                    records=smoke_records,
                ),
            )
            print("Smoke passed; these tiny runs are not research results.", flush=True)
            return
        try:
            records = [ensure(spec) for spec in tuning_specs(args.study)]
            selection = select_trials(records)
            path = run_dir / "selection.json"
            if path.exists() and json.loads(path.read_text()) != selection:
                raise ValueError("Frozen selection differs from tuning records.")
            atomic_json(path, selection)
            for specs in confirmation_specs(args.study, selection).values():
                for spec in specs:
                    ensure(spec)
        except TimeoutError as error:
            print(error, flush=True)
        summary = summarize(run_dir)
        atomic_json(run_dir / "summary.json", summary)
        print(json.dumps(summary, indent=2), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("run", "smoke", "summarize"):
        child = commands.add_parser(command)
        child.add_argument("--run-dir", type=Path, required=True)
        if command == "summarize":
            continue
        child.add_argument("--study", choices=STUDIES, required=True)
        child.add_argument("--data-root", type=Path, default=ROOT / "data")
        child.add_argument("--device", default="auto")
        child.add_argument("--download", action="store_true")
        child.add_argument("--max-seconds", type=float, default=6600)
        child.add_argument(
            "--threads", type=int, default=1 if command == "smoke" else 4
        )
        if command == "smoke":
            smoke_mode = child.add_mutually_exclusive_group()
            smoke_mode.add_argument("--synthetic", action="store_true")
            smoke_mode.add_argument(
                "--real",
                action="store_true",
                help="time a full-size real-data epoch, without test evaluation",
            )
    args = parser.parse_args()
    if args.command == "summarize":
        print(json.dumps(summarize(args.run_dir), indent=2))
        return
    if args.max_seconds <= 0 or not np.isfinite(args.max_seconds) or args.threads <= 0:
        parser.error(
            "max-seconds must be finite and positive; threads must be positive"
        )
    torch.set_num_threads(args.threads)
    execute(args)


if __name__ == "__main__":
    main()
