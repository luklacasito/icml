#!/usr/bin/env python3
"""Restore and verify a frozen scientific snapshot; never start training."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", required=True, choices=("pilot", "expanded"))
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    capsule = Path(__file__).resolve().parent
    manifest = json.loads((capsule / "studies" / (args.study + ".json")).read_text())
    prepared = []
    for name, expected in manifest["files"].items():
        rel = PurePosixPath(name)
        if rel.is_absolute() or ".." in rel.parts:
            raise ValueError("Unsafe relative source path")
        data = (capsule / "blobs" / (expected + ".py")).read_bytes()
        if digest(data) != expected:
            raise ValueError("Blob checksum mismatch: " + name)
        target = args.output.joinpath(*rel.parts)
        if target.exists() and (not target.is_file() or target.read_bytes() != data):
            raise FileExistsError("Existing source differs: " + str(target))
        prepared.append((name, target, data))
    for name, target, data in prepared:
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(data)
    restored = {}
    for name, target, data in prepared:
        actual = digest(target.read_bytes())
        if actual != manifest["files"][name]:
            raise ValueError("Restored checksum mismatch: " + name)
        restored[name] = actual
    fingerprint = {name: restored[name] for name in manifest["fingerprint_paths"]}
    encoded = json.dumps(fingerprint, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    actual = digest(encoded)
    if actual != manifest["scientific_source_hash"]:
        raise ValueError("Scientific source fingerprint mismatch")
    print(args.study + ": verified " + str(len(restored)) + " files; " + actual)


if __name__ == "__main__":
    main()
